package med.spelling.corrector;

import java.util.*;

public interface SpellingSuggest {

	public List<String> suggestions(String word, int numSuggestions);
	
}
